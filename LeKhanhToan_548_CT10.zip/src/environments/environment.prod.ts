export const environment = {
  production: true,
   firebaseConfig:{
    apiKey: "AIzaSyCiKWnuWy9eppqyYdC0JJP0ssiQICF06xU",
    authDomain: "camelia-authentic.firebaseapp.com",
    projectId: "camelia-authentic",
    storageBucket: "camelia-authentic.appspot.com",
    messagingSenderId: "76800127762",
    appId: "1:76800127762:web:d821ab61335efb3f91b9cb"
  }
  
};
